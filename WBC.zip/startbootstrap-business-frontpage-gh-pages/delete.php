<?php
// include database connection
include 'MySqlYhteydenotto.php';
 
try {
     
    // get record maksutID
    // isset() is a PHP function used to verify if a value is there or not
    $maksutID=isset($_GET['maksutID']) ? $_GET['maksutID'] : die('ERROR: Record maksutID not found.');

    // delete query
    $query = "DELETE FROM maksut WHERE maksutID = :maksutID";
    $stmt = $yhteys->prepare($query);
    $stmt->bindParam(':maksutID', $maksutID);
     
    if($stmt->execute()){
        // redirect to read records page and 
        // tell the user record was deleted
        header('Location: haeMaksut.php?action=deleted');
    }else{
        die('Unable to delete record.');
    }
}
 
// show error
catch(PDOException $exception){
    die('Et voi poistaa urheilijaa, jolla on maksuja: ' );
}
?>