<!DOCTYPE HTML>
<html>
<head>
    <title>Näytä maksut</title>
     
    <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" 
	href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
         
    <!-- custom css -->
    <style>
    .m-r-1em{ margin-right:1em; }
    .m-b-1em{ margin-bottom:1em; }
    .m-l-1em{ margin-left:1em; }
    .mt0{ margin-top:0; }
    </style>
</head>
<body>
  <a href="admin.html">Takaisin </a> 
  
    <div class="container">
  
        <div class="page-header">
            <h1>Maksutiedot</h1>
        </div>
 <?php
  include 'MySqlYhteydenotto.php';
 
  $action = isset($_GET['action']) ? $_GET['action'] : "";

  // if it was redirected from delete.php
if($action=='deleted'){
    echo "<div class='alert alert-success'>Record was deleted.</div>";
}


  $sqlLause = "SELECT maksutID,urheilijaID, tuoteID, hinta, kappaleMaara FROM maksut ";
  $komento = $yhteys->prepare($sqlLause);
  $komento->execute();
  ;
  // palautettujen rivien lukumäärä saadaan näin
  $num = $komento->rowCount();
 
  // link to create record form
  echo "<a href='lisaaUusiMaksuAjaxilla.php' class='btn btn-primary m-b-1em'>Lisää uusi maksu</a>";
 
  //check if more than 0 record found
  if($num>0){
 
    echo "<table class='table table-hover table-responsive table-bordered'>";//start table
 
    echo "<tr>";
		echo "<th>maksutID</th>"; 
        echo "<th>urheilijaID</th>";
		echo "<th>hinta</th>";
		echo "<th>kappaleMaara</th>";
        echo "<th>action</th>";
    echo "</tr>";
     
  // haetaan kaikki urheilijat
  // fetch() on nopeampi kuin fetchAll()
 

  while ($rivi = $komento->fetch(PDO::FETCH_ASSOC)){
     // extract muuttaa
     //  $rivi['osnimi'] taulukosta alkiot vastaaviin muuttujiin $osnimi 
     extract($rivi);
     
     // tehdään jokaisesta urheilijataulun rivistä oma rivi tauluun
        echo "<tr>";
		echo "<td>{$maksutID}</td>";
        echo "<td>{$urheilijaID}</td>";
        echo "<td>{$hinta}</td>";
		echo "<td>{$kappaleMaara}</td>";
        echo "<td>";
            echo "<a href='NaytaYksiMaksu.php?maksutID={$maksutID}' class='btn btn-info m-r-1em'>Lue maksun tiedot</a>";
            echo "<a href='MuokkaaMaksua.php?maksutID={$maksutID}' class='btn btn-primary m-r-1em'>Muokkaa maksua</a>";
            echo "<a href='delete.php?maksutID={$maksutID}' class='btn btn-danger'>Poista maksu</a>";
        echo "</td>";
    echo "</tr>";
}
echo "</table>"; 
}
 
// jos ei löytynyt yhtään
else{
    echo "<div class='alert alert-danger'>Maksua ei löytynyt.</div>";
}
?>
         
 </div> <!-- end .container -->
     
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
   
<!-- Latest compiled and minified Bootstrap JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
 
 <!-- confirm delete record will be here -->
<script type='text/javascript'>
// confirm record deletion
function delete_user( maksutID ){
     
    var answer = confirm('Oletko varma?');
    if (answer){
        // if user clicked ok, 
        // pass the id to delete.php and execute the delete query
        window.location = 'delete.php?maksutID=' + maksutID;
    } 
}
</body>
</html>