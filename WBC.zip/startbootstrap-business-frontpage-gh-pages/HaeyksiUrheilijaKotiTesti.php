<!DOCTYPE HTML>
<html>
<head>
    <title>PDO - Lue yksi urheilija</title>
 
    <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
 
</head>
<body>
 
 
    <!-- container -->
    <div class="container">
  
        <div class="page-header">
            <h1>Näytä yksi urheilija</h1>
        </div>
         
        <?php
// get passed parameter value, in this case, the record ID
// isset() is a PHP function used to verify if a value is there or not

     
$urheilijaID = "";
$etuNimi = "";
$sukuNimi = "";
    if (isset($_GET["urheilijaID"]))
    {
        $urheilijaID = $_GET["urheilijaID"];
    }
    else
    {
        die('ERROR: urheilijaa ei löydy.');
    }
//$id=isset($_GET['id']) ? $_GET['id'] : die('ERROR: Record ID not found.');
 
include 'MySqlYhteydenotto.php';

// read current record's data
try {
    // prepare select query
    $query = "SELECT etuNimi, sukuNimi FROM urheilija where urheilijaID  ";
    $stmt = $yhteys->prepare( $query );
 
    // Sidotaan saatu urheilijatunnus kyselyyn
    $stmt->bindParam($urheilijaID);
 
 
    // suorita haku
    $stmt->execute();
    // $lukumaara = $stmt->rowCount();
    // if ($lukumaara  === 0)
    // {
    //     die('ERROR: urheilijaja löytyy nolla.');
    // }
        // urheilijatieto siirretään rivi-nimiseen assosiatiiviseen muuttujaan
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
 
    // values to fill up our form
    $uheilijaID = $row['urheilijaID'];
    $etuNimi = $row['etuNimi'];
    $sukuNimi = $row['sukuNimi'];
}	
 
// show error
catch(PDOException $exception){
    die('ERROR: ' . $exception->getMessage());
}
<?php
 
// check if form was submitted
if($_GET){
     
    try{
     
        // write update query
        // in this case, it seemed like we have so many fields to pass and 
        // it is better to label them and not use question marks
        $query = "UPDATE urheilija 
                    SET urheilijaID=:urheilijaID, etuNimi=:etuNimi, sukuNimi=:sukuNimi 
                    WHERE  = :urheilijaID";
 
        // prepare query for excecution
        $stmt = $yhteys->prepare($query);
 
        // posted values
        $urheilijaID=htmlspecialchars(strip_tags($_GET['urheilijaID']));
        $etuNimi=htmlspecialchars(strip_tags($_GET['etuNimi']));
        $sukuNimi=htmlspecialchars(strip_tags($_GET['sukuNimi']));
 
        // bind the parameters
        $stmt->bindParam(':urheilijaID', $urheilijaID);
        $stmt->bindParam(':etuNimi', $etuNimi);
        $stmt->bindParam(':sukuNimi', $sukuNimi);
         
        // Execute the query
        if($stmt->execute()){
            echo "<div class='alert alert-success'>Record was updated.</div>";
        }else{
            echo "<div class='alert alert-danger'>Unable to update record. Please try again.</div>";
        }
         
    }
     
    // show errors
    catch(PDOException $exception){
        die('ERROR: ' . $exception->getMessage());
    }
}
?>
?>
 
     <!--we have our html table here where the record will be displayed-->
     <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . "?UrheilijaID={$urheilijaID}");?>" method="GET">
    <table class='table table-hover table-responsive table-bordered'>
    <tr>
        <td>urheilijatunnus</td>
        <td><?php echo htmlspecialchars($urheilijaID, ENT_QUOTES);  ?></td>
    </tr>
    <tr>
        <td>Etunimi</td>
        <td><?php echo htmlspecialchars($etuNimi, ENT_QUOTES);  ?></td>
    </tr>
    <tr>
        <td>sukuNimi</td>
        <td><?php echo htmlspecialchars($sukuNimi, ENT_QUOTES);  ?></td>
    </tr>

    <tr>
        <td></td>
        <td>
            <input type='submit' value='Save Changes' class='btn btn-primary' />
            <a href='haeUrheilijat.php' class='btn btn-danger'>Takaisin usean urheilijan näytölle</a>
        </td>
    </tr>
</table>
 
    </div> <!-- end .container -->
     
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
   
<!-- Latest compiled and minified Bootstrap JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
</body>
</html>