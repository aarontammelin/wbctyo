<!DOCTYPE HTML>
<html>
<head>
    <title>PDO - Lue yksi urheilija</title>
 
    <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
 
</head>
<body>
 
 
    <!-- container -->
    <div class="container">
  
        <div class="page-header">
            <h1>Näytä yksi urheilija</h1>
        </div>
         
  <?php

     echo "huhuu";
$maksutID = "";
$urheilijaID = "";
$hinta = "";
$kappaleMaara = "";
$tuoteID ="";
    if (isset($_GET["maksutID"]))
    {
        $maksutID = $_GET["maksutID"];
    }
    else
    {
        die('ERROR: maksua ei löydy.');
    }
//$id=isset($_GET['id']) ? $_GET['id'] : die('ERROR: Record ID not found.');
 
include 'MySqlYhteydenotto.php';

// 
try {
    // prepare select query
    $query = "SELECT urheilijaID, etuNimi, sukuNimi,  hinta, kappaleMaara, tuoteNimi 
	FROM maksut INNER JOIN tuotteet ON maksut.tuoteID =tuotteet.tuoteID 
	INNER JOIN urheilija ON urheilija.urheilijaID =maksut.urheilijaID	where maksutID = :maksutID  ";
    $stmt = $yhteys->prepare( $query );
 
    // Sidotaan saatu urheilijatunnus kyselyyn
    $stmt->bindParam(':maksutID', $maksutID);
 
 
    // suorita haku
    $stmt->execute();
    $lukumaara = $stmt->rowCount();
	echo $lukumaara;
    if ($lukumaara  === 0)
    {
        die('ERROR: urheilijaja löytyy nolla.');
    }
        // urheilijatieto siirretään rivi-nimiseen assosiatiiviseen muuttujaan
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
 
    // values to fill up our form
    extract $row;
}	
 
// show error
catch(PDOException $exception){
    die('ERROR: ' . $exception->getMessage());
}
?>
 
     <!--we have our html table here where the record will be displayed-->
<table class='table table-hover table-responsive table-bordered'>
    <tr>
        <td>Maksun tunnus</td>
        <td><?php echo htmlspecialchars($maksutID, ENT_QUOTES);  ?></td>
    </tr>
    <tr>
        <td>urheilijatunnus</td>
        <td><?php echo htmlspecialchars($urheilijaID, ENT_QUOTES);  ?></td>
    </tr>
    <tr>
        <td>hinta</td>
        <td><?php echo htmlspecialchars($hinta, ENT_QUOTES);  ?></td>
    </tr>
	    <tr>
        <td>tuote</td>
        <td><?php echo htmlspecialchars($tuoteNimi, ENT_QUOTES);  ?></td>
    </tr>

    <tr>
        <td></td>
        <td>
            <a href='haeUrheilijat.php' class='btn btn-danger'>Takaisin usean urheilijan näytölle</a>
        </td>
    </tr>
</table>
 
    </div> <!-- end .container -->
     
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
   
<!-- Latest compiled and minified Bootstrap JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
</body>
</html>