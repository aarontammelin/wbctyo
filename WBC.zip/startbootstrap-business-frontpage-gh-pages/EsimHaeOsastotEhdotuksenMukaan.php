<?php
 $tuoteNimi = "";
 
    if (isset($_POST["tuoteNimenAlku"]))
    {
        $tuoteNimi = $_POST["tuoteNimenAlku"];
		// hakukentän perään laitetaan %-merkki, jotta saadaan hakukentän mukaan alkavat tiedot haettua
		$tuoteNimi = $tuoteNimi . "%";
    }
    else
    {
        die('Haettava tieto ei tule oikein selaimelta.');
    }
 
include 'MySqlYhteydenotto.php';

// 
try 
  {
    // prepare select query
    $query = "SELECT  tuoteID FROM tuotteet WHERE tuoteNimi LIKE :tuoteNimi ";
    $stmt = $yhteys->prepare( $query );
    // Sidotaan saatu osaston nimi kyselyyn
    $stmt->bindParam(':tuoteNimi', $tuoteNimi);
	
	
	
 
    // suorita haku
    $stmt->execute();
    $lukumaara = $stmt->rowCount();
    
	if ($lukumaara  === 0)
    {
        die('Haettavia tuotteita ei löydy tällä hakukriteerillä.');
    }
	
        // osastotieto siirretään rivi-nimiseen assosiatiiviseen muuttujaan
    echo "<select>"; 
    while ($rivi = $stmt->fetch(PDO::FETCH_ASSOC))
    {

       extract($rivi);
     
       // tehdään jokaisesta osastotaulun rivistä oma rivi tauluun
       echo "<option>" . "{$tuoteID}" . " " . "{$tuoteNimi}" . " </option>  ";
        
    }
	    echo "</select>"; 
  }
 
// show error
catch(PDOException $exception)
  {
    die('Virhe ohjelmointikoodissa: ' . $exception->getMessage());
  }
?>
