<!DOCTYPE HTML>
<html>
<head>
    <title>PDO - Update a Record - PHP CRUD Tutorial</title>
     
    <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
         
</head>
<body>
 
    <!-- container -->
    <div class="container">
  
        <div class="page-header">
            <h1>Update Product</h1>
        </div>
     
        <!-- PHP read record by ID will be here -->
        <?php
// get passed parameter value, in this case, the record ID
// isset() is a PHP function used to verify if a value is there or not
$maksutID=isset($_GET['maksutID']) ? $_GET['maksutID'] : die('ERROR: Record maksutID not found.');
 
//include database connection
include 'MySqlYhteydenotto.php';
 
// read current record's data
try {
    // prepare select query
    $query = "SELECT urheilija.urheilijaID , etuNimi, sukuNimi, maksut.hinta , kappaleMaara, tuotteet.hinta AS tuoteHinta, tuoteNimi FROM maksut INNER JOIN tuotteet ON maksut.tuoteID =tuotteet.tuoteID INNER JOIN urheilija ON urheilija.urheilijaID =maksut.urheilijaID where maksutID =:maksutID ";
    $stmt = $yhteys->prepare( $query );
     
    // this is the first question mark
    $stmt->bindParam('maksutID', $maksutID);
     
    // execute our query
    $stmt->execute();
     
    // store retrieved row to a variable
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
     
    // values to fill up our form
	
	extract ($row);
	$yhtHinta= $tuoteHinta*$kappaleMaara;
	
}
 
// show error
catch(PDOException $exception){
    die('ERROR: ' . $exception->getMessage());
}
?>
        <!-- HTML form to update record will be here -->
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . "?maksutID={$maksutID}");?>" method="post">
    <table class='table table-hover table-responsive table-bordered'>
        <tr>
            <td>urheilijatunnus (ei muokattava)</td>
            <td><textarea name='urheilijaID' class='form-control'><?php echo htmlspecialchars($urheilijaID, ENT_QUOTES);  ?></textarea></td>
        </tr>
        <tr>
            <td>Maksun tunnus (ei muokattava)</td>
            <td><textarea name='maksutID' class='form-control'><?php echo htmlspecialchars($maksutID, ENT_QUOTES);  ?></textarea></td>
        </tr>
        <tr>
            <td>Kappalemäärä</td>
            <td><input type='text' name='kappaleMaara' value="<?php echo htmlspecialchars($kappaleMaara, ENT_QUOTES);  ?>" class='form-control' /></td>
        </tr>
        <tr>
		<tr>
            <td>Kokonaishinta</td>
            <td><input type='text' name='yhtHinta' value="<?php echo htmlspecialchars($yhtHinta, ENT_QUOTES);  ?>" class='form-control' /></td>
        </tr>
	
		<tr>
            <td>Hinta per tuote </td>
            <td><input type='text' name='tuoteHinta' value="<?php echo htmlspecialchars($tuoteHinta, ENT_QUOTES);  ?>" class='form-control' /></td>
        </tr>
	
			<tr>
            <td>tuoteNimi (ei muokattava)</td>
            <td><textarea name='tuoteNimi' class='form-control'><?php echo htmlspecialchars($tuoteNimi, ENT_QUOTES);  ?></textarea></td>
        </tr>
		
		<tr>
            <td></td>
            <td>
                <input type='submit' value='Save Changes' class='btn btn-primary' />
                <a href='haeMaksut.php' class='btn btn-danger'>Back to read products</a>
            </td>
			
			
        </tr>
    </table>
</form>         
    </div> <!-- end .container -->
     
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
   
<!-- Latest compiled and minified Bootstrap JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- PHP post to update record will be here -->
<?php
 
// check if form was submitted
if($_POST){
     
    try{
     
        // write update query
        // in this case, it seemed like we have so many fields to pass and 
        // it is better to label them and not use question marks
        $query = "UPDATE maksut 
                    SET maksutID=:maksutID, kappaleMaara=:kappaleMaara, hinta=:hinta 
                    WHERE maksutID = :maksutID";
 
        // prepare query for excecution
        $stmt = $yhteys->prepare($query);
		
        // posted values
        $maksutID=htmlspecialchars(strip_tags($_POST['maksutID']));
        $kappaleMaara=htmlspecialchars(strip_tags($_POST['kappaleMaara']));
        $hinta=htmlspecialchars(strip_tags($_POST['hinta']));
		$tuoteHinta=htmlspecialchars(strip_tags($_POST['tuoteHinta']));
        
 
        // bind the parameters
        $stmt->bindParam(':maksutID', $maksutID);
        $stmt->bindParam(':kappaleMaara', $kappaleMaara);
        $stmt->bindParam(':hinta', $hinta);
		$stmt->bindParam(':tuoteHinta', $tuoteHinta);
        
         $hinta=$yhtHinta;
        // Execute the query
        if($stmt->execute()){
            echo "<div class='alert alert-success'>Maksu tallentui onnistuneesti.</div>";
        }else{
            echo "<div class='alert alert-danger'>Unable to update record. Please try again.</div>";
        }
         
    }
     
    // show errors
    catch(PDOException $exception){
        die('ERROR: ' . $exception->getMessage());
    }
}
?> 
<!--we have our html form here where new record information can be updated-->

 
</body>
</html>