<!DOCTYPE HTML>
<html>
<head>
    <title>PDO - Ylläpito</title>
     
    <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
         
</head>
<body>
 
    <!-- container -->
    <div class="container">
  
        <div class="page-header">
            <h1>Osaston tietojen muutos</h1>
        </div>
     
        <?php
// isset() is a PHP funktio, jolla voidaan varmistaa onko muuttujalla arvo vai ei
     
$urheilijaID = "";
$etuNimi = "";
$sukuNimi = "";

    if (isset($_GET["urheilijaID"]))
    {
        $urheilijaID = $_GET["urheilijaID"];
    }
    else
    {
        die('ERROR: Osastoa ei löydy.');
    }

include 'MySqlYhteydenotto.php';
 
// luetaan muutettavaksi pyydetty
try {
   // prepare select
   $sqlLause = "SELECT urheilijaID, etuNimi, sukuNimi FROM osasto WHERE urheilijaID = :urheilijaID ";
   $komento = $yhteys->prepare( $sqlLause );

   // Sidotaan saatu osastotunnus kyselyyn
   $komento->bindParam(':urheilijaID', $urheilijaID);


   // suorita haku
   $komento->execute();
   $lukumaara = $komento->rowCount();
   if ($lukumaara  === 0)
   {
       die('ERROR: Osastoja löytyy nolla.');
   }
       // osastotieto siirretään rivi-nimiseen assosiatiiviseen muuttujaan
   $row = $komento->fetch(PDO::FETCH_ASSOC);

   // values to fill up our form
   $urheilijaID = $row['urheilijaID'];
   $etuNimi = $row['etuNimi'];
   $sukuNimi = $row['sukuNimi'];
}
 
// show error
catch(PDOException $exception){
    die('ERROR: ' . $exception->getMessage());
}
?>

<?php
 
// check if form was submitted
if($_GET){
     
    try{
     
        // write update query
        // in this case, it seemed like we have so many fields to pass and 
        // it is better to label them and not use question marks
        $sqlLause = "UPDATE urheilija 
                    SET etuNimi=:etuNimi, sukuNimi=:sukuNimi 
                    WHERE urheilijaID = :urheilijaID";
 
        // prepare query for excecution
        $komento = $yhteys->prepare($sqlLause);
 
        // GETed values
        $urheilijaID=htmlspecialchars(strip_tags($_GET['urheilijaID']));
        $etuNimi=htmlspecialchars(strip_tags($_GET['etuNimi']));
        $sukuNimi=htmlspecialchars(strip_tags($_GET['sukuNimi']));
 
        // bind the parameters
        $komento->bindParam(':urheilijaID', $urheilijaID);
        $komento->bindParam(':etuNimi', $etuNimi);
        $komento->bindParam(':sukuNimi', $sukuNimi);
         
        if($komento->execute()){
            echo "<div class='alert alert-success'>Osastotiedot muutettu.</div>";
        }else{
            echo "<div class='alert alert-danger'>Osastotietoja ei muutettu.</div>";
        }
         
    }
     
    // show errors
    catch(PDOException $exception){
        die('ERROR: ' . $exception->getMessage());
    }
}
?>
 
<!--Taulussa osastotieto muutettavaksi -->
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . "?urheilijaID={$urheilijaID}");?>" method="GET">
    <table class='table table-hover table-responsive table-bordered'>
        <tr>
			<td>Osastotunnus</td>
            <td><input type='text' name='urheilijaID' value="<?php echo htmlspecialchars($urheilijaID, ENT_QUOTES);  ?>" class='form-control' /></td>
        </tr>
        <tr>
            <td>Osaston nimi</td>
            <td><textarea name='etuNimi' class='form-control'><?php echo htmlspecialchars($etuNimi, ENT_QUOTES);  ?></textarea></td>
        </tr>
        <tr>
            <td>sukuNimi</td>
            <td><input type='text' name='sukuNimi' value="<?php echo htmlspecialchars($sukuNimi, ENT_QUOTES);  ?>" class='form-control' /></td>
        </tr>
        <tr>
            <td></td>
            <td>
                <input type='submit' value='Talleta muutokset' class='btn btn-primary' />
                <a href='haeUrheilijat.php' class='btn btn-danger'>Takaisin osastojen näytölle</a>
            </td>
        </tr>
    </table>
</form>

        
    </div> <!-- end .container -->
     
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
   
<!-- Latest compiled and minified Bootstrap JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
</body>
</html>