 <!DOCTYPE HTML>
<html>
<head>
    <title>PDO-rajapinnalla toteutettu Osasto-tiedon lisääminen, Bootstrap-kirjasto käytössä</title>
      
    <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
          
</head>
<body>
  
    <!-- container -->
<div class="container">
   
        <div class="page-header">
            <h1>Lisää osasto</h1>
        </div>
	<!-- PHP insert code will be here -->
<?php

// ensin ehto, joka varmistaa, että käyttäjä näkee ensin lomakkeen ja vasta sen jälkeen kun 
// lomakkeelta lähetetään tietoa, tapahtuu tämä php-koodi

	if($_POST){
        
    // include hakee yhteyden tietokantaan, jossa on osasto-taulu, yhteys-objektille on annettu nimi $yhteys
    include 'MySqlYhteydenotto.php';
 
    try{
		// tehdään insert eli tietorivin lisääminen tietokantaan
		// insert-kysely muodostetaan käyttäen nimettyjä parametreja
		// lisättävien tietojen sijalla
		$lisayskomento = "insert into urheilija set urheilijaID = :urheilijaID, etuNimi = :etuNimi, sukuNimi = :sukuNimi, puhelinnumero = :puhelinnumero, sahkoPosti = :sahkoPosti, 
			syntymaAika = :syntymaAika, lahiOsoite = :lahiOsoite, postiNumero = :postiNumero, postitoimipaikka = :postitoimipaikka";
		$sqlLause = $yhteys->prepare($lisayskomento);
		
		// haetaan käyttäjän antamat tiedot ja putsataa nne Laittomuuksista
		$urheilijaID = htmlspecialchars(strip_tags($_POST["urheilijaID"]));
		$sukuNimi = htmlspecialchars(strip_tags($_POST["sukuNimi"]));
		$etuNimi = htmlspecialchars(strip_tags($_POST["etuNimi"]));
		$puhelinnumero = htmlspecialchars(strip_tags($_POST["puhelinnumero"]));
		$sahkoPosti = htmlspecialchars(strip_tags($_POST["sahkoposti"]));
		$syntymaAika = htmlspecialchars(strip_tags($_POST["syntymaAika"]));
		$lahiOsoite = htmlspecialchars(strip_tags($_POST["lahiOsoite"]));
		$postiNumero = htmlspecialchars(strip_tags($_POST["postiNumero"]));
		$postitoimipaikka = htmlspecialchars(strip_tags($_POST["postitoimipaikka"]));
		// laitetaan käyttäjän antamat tiedot nimettyjen parametrien tilalle
		$sqlLause->bindParam('urheilijaID', $urheilijaID);
		$sqlLause->bindParam('sukuNimi', $sukuNimi);
		$sqlLause->bindParam('etuNimi', $etuNimi);
		$sqlLause->bindParam('puhelinnumero', $puhelinnumero);
		$sqlLause->bindParam('sahkoPosti', $sahkoPosti);
		$sqlLause->bindParam('syntymaAika', $syntymaAika);
		$sqlLause->bindParam('lahiOsoite', $lahiOsoite);
		$sqlLause->bindParam('postiNumero', $postiNumero);
		$sqlLause->bindParam('postitoimipaikka', $postitoimipaikka);
		
		// suorita kysely käyttäjän antamilla tiedoilla
		if ($sqlLause->execute()){
			echo "<div class='alert alert-success'>Osastotieto on lisätty.</div>";
		}else {
			echo "<div class='alert alert-success'>Osastotieto EI lisätty.</div>";
		}
         
    }
     
    // show error
    catch(PDOException $exception){
        die('ERROR: ' . $exception->getMessage());
    }
}
?>
	
 
<!-- html form - kutsuu itseään, eli php-koodi on tässä samassa tiedostossa tuossa yläpuolella -->
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
    <table class='table table-hover table-responsive table-bordered'>
        <tr>
            <td>UrheilijaID</td>
            <td><input type='text' name='urheilijaID' class='form-control' /></td>
        </tr>
		    <tr>
            <td>Sukunimi</td>
            <td><input type='text' name='sukuNimi' class='form-control' /></td>
        </tr>
		    <tr>
            <td>Etunimi</td>
            <td><input type='text' name='etuNimi' class='form-control' /></td>
        </tr>
		    <tr>
            <td>Puhelinnumero</td>
            <td><input type='text' name='puhelinnumero' class='form-control' /></td>
        </tr>
		    <tr>
            <td>Sahkoposti</td>
            <td><input type='text' name='sahkoPosti' class='form-control' /></td>
        </tr>
		    <tr>
            <td>Syntymäaika</td>
            <td><input type='text' name='' class='form-control' /></td>
        </tr>
        <tr>
            <td>Lahiosoite</td>
            <td><textarea type='text' name='lahiOsoite' class='form-control'></textarea></td>
        </tr>
		    <tr>
            <td>Postinumero</td>
            <td><input type='text' name='postiNumero' class='form-control' /></td>
        </tr>
		    <tr>
            <td>Postitoimipaikka</td>
            <td><input type='text' name='postitoimipaikka' class='form-control' /></td>
        </tr>
		

        <tr>
            <td></td>
            <td>
                <input type='submit' value='Lisää osasto' class='btn btn-primary' />
                <a href='haeUrheilijat.php' class='btn btn-info'>Takaisin osastohakuun</a>
                     <!-- painiketyylejä:  https://www.w3schools.com/bootstrap/tryit.asp?filename=trybs_button_styles&stacked=h  -->
            </td>
        </tr>
    </table>
</form>

          
 </div> <!-- end .container -->
      
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
   
<!-- Latest compiled and minified Bootstrap JavaScript 
https://www.codeofaninja.com/2011/12/php-and-mysql-crud-tutorial.html
-->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
</body>
</html>
