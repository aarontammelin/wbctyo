<!DOCTYPE HTML>
<html>
<head>
    <title>PDO - Read One Record - PHP CRUD Tutorial</title>
 
    <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
 
</head>
<body>
 
 
    <!-- container -->
    <div class="container">
  
        <div class="page-header">
            <h1>Read Product</h1>
        </div>
         
        <!-- PHP read one record will be here -->
 
 <?php
// get passed parameter value, in this case, the record urheilijaID
// isset() is a PHP function used to verify if a value is there or not
$urheilijaID=isset($_GET['urheilijaID']) ? $_GET['urheilijaID'] : die('ERROR: Record urheilijaID not found.');
 
//include database connection
include 'MySqlYhteydenotto.php';
 
// read current record's data
try {
    // prepare select query
    $query = "SELECT urheilijaID, etuNimi, sukuNimi FROM urheilija WHERE urheilijaID = :urheilijaID";
    $stmt = $con->prepare( $query );
 
    // this is the first question mark
    $stmt->bindParam($urheilijaID);
 
    // execute our query
    $stmt->execute();
 
    // store retrieved row to a variable
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
 
    // values to fill up our form
    $urheilijaID = $row['urheilijaID'];
    $etuNimi = $row['etuNimi'];
    $sukuNimi = $row['sukuNimi'];
}
 
// show error
catch(PDOException $exception){
    die('ERROR: ' . $exception->getMessage());
}
?>
        <!-- HTML read one record table will be here -->
 <!--we have our html table here where the record will be displayed-->

 <table class='table table-hover table-responsive table-bordered'>
    <tr>
        <td>UrheilijaID</td>
        <td><?php echo htmlspecialchars($urheilijaID, ENT_QUOTES);  ?></td>
    </tr>
    <tr>
        <td>Etunimi</td>
        <td><?php echo htmlspecialchars($etuNimi, ENT_QUOTES);  ?></td>
    </tr>
    <tr>
        <td>Sukunimi</td>
        <td><?php echo htmlspecialchars($sukuNimi, ENT_QUOTES);  ?></td>
    </tr>
    <tr>
        <td></td>
        <td>
            <a href='haeUrheilijat.php' class='btn btn-danger'>Back to read products</a>
        </td>
    </tr>
</table>
    </div> <!-- end .container -->
     
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
   
<!-- Latest compiled and minified Bootstrap JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
</body>
</html>