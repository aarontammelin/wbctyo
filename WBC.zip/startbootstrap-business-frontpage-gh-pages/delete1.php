<?php
// include database connection
include 'MySqlYhteydenotto.php';
 
try {
     
    // get record urheilijaID
    // isset() is a PHP function used to verify if a value is there or not
    $urheilijaID=isset($_GET['urheilijaID']) ? $_GET['urheilijaID'] : die('ERROR: Record urheilijaID not found.');

    // delete query
    $query = "DELETE FROM urheilija WHERE urheilijaID = :urheilijaID";
    $stmt = $yhteys->prepare($query);
    $stmt->bindParam(':urheilijaID', $urheilijaID);
     
    if($stmt->execute()){
        // redirect to read records page and 
        // tell the user record was deleted
        header('Location: haeUrheilijat.php?action=deleted');
    }else{
        die('Unable to delete record.');
    }
}
 
// show error
catch(PDOException $exception){
    die('Et voi poistaa urheilijaa, jolla on maksuja: ' );
}
?>