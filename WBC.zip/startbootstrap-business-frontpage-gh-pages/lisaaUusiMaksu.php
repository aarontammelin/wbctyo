 <!DOCTYPE HTML>
<html>
<head>
    <title>PDO-rajapinnalla toteutettu Osasto-tiedon lisääminen, Bootstrap-kirjasto käytössä</title>
      
    <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />



      
</head>
<body>
  
    <!-- container -->
<div class="container">
   
        <div class="page-header">
            <h1>Lisää osasto</h1>
        </div>
	<!-- PHP insert code will be here -->
<?php

// ensin ehto, joka varmistaa, että käyttäjä näkee ensin lomakkeen ja vasta sen jälkeen kun 
// lomakkeelta lähetetään tietoa, tapahtuu tämä php-koodi

	if($_POST){
        
    // include hakee yhteyden tietokantaan, jossa on osasto-taulu, yhteys-objektille on annettu nimi $yhteys
    include 'MySqlYhteydenotto.php';
 
    try{
		// tehdään insert eli tietorivin lisääminen tietokantaan
		// insert-kysely muodostetaan käyttäen nimettyjä parametreja
		// lisättävien tietojen sijalla
		$lisayskomento = "insert into maksut set maksutID = :maksutID, urheilijaID= :urheilijaID, tuoteID =:tuoteID, 
		hinta= :hinta, kappaleMaara =:kappaleMaara"; 
		$sqlLause = $yhteys->prepare($lisayskomento);
		
		// haetaan käyttäjän antamat tiedot ja putsataa nne Laittomuuksista
		$maksutID = htmlspecialchars(strip_tags($_POST["maksutID"]));
		$urheilijaID = htmlspecialchars(strip_tags($_POST["urheilijaID"]));
		$tuoteID = htmlspecialchars(strip_tags($_POST["tuoteID"]));
		$hinta = htmlspecialchars(strip_tags($_POST["hinta"]));
		$kappaleMaara = htmlspecialchars(strip_tags($_POST["kappaleMaara"]));
		// laitetaan käyttäjän antamat tiedot nimettyjen parametrien tilalle
		$sqlLause->bindParam('maksutID', $maksutID);
		$sqlLause->bindParam('urheilijaID', $urheilijaID);
		$sqlLause->bindParam('tuoteID', $tuoteID);
		$sqlLause->bindParam('hinta', $hinta);
		$sqlLause->bindParam('kappaleMaara', $kappaleMaara);

		
		// suorita kysely käyttäjän antamilla tiedoilla
		if ($sqlLause->execute()){
			echo "<div class='alert alert-success'>Maksu lisätty.</div>";
		}else {
			echo "<div class='alert alert-success'>Maksua EI lisätty.</div>";
		}
         
    }
     
    // show error
    catch(PDOException $exception){
        die('ERROR: ' . $exception->getMessage());
    }
}
?>
	
 
<!-- html form - kutsuu itseään, eli php-koodi on tässä samassa tiedostossa tuossa yläpuolella -->
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
    <table class='table table-hover table-responsive table-bordered'>
        <!--<tr>
            <td>maksutID</td>
            <td><textarea name='maksutID' class='form-control'><?php echo htmlspecialchars($maksutID, ENT_QUOTES);  ?></textarea></td>
        </tr> -->
		    <tr>
            <td>urheilijaID</td>
            <td><input type='text' name='urheilijaID' class='form-control' /></td>
        </tr>
		    <tr>
            <td>Tuote</td>
            <td><input type='text' name='tuoteID' id='tuoteID' class='form-control' /></td>
        </tr>
		<!--
				<tr>
				<td>Hinta</td>
				<td><input type='text' name='hinta' class='form-control' /></td>
			</tr>
			-->
		    <tr>
            <td>Kappalemäärä</td>
            <td><input type='text' name='kappaleMaara' class='form-control' /></td>
        </tr>
        <tr>
            <td></td>
            <td>
                <input type='submit' value='Lisää maksu' class='btn btn-primary' />
                <a href='haeMaksut.php' class='btn btn-info'>Takaisin maksuihin</a>
                     <!-- painiketyylejä:  https://www.w3schools.com/bootstrap/tryit.asp?filename=trybs_button_styles&stacked=h  -->
            </td>
        </tr>
    </table>
</form>

          
 </div> <!-- end .container -->
      
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
   
<!-- Latest compiled and minified Bootstrap JavaScript 
https://www.codeofaninja.com/2011/12/php-and-mysql-crud-tutorial.html
-->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
</body>
</html>
